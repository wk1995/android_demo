package com.tuya.smart.sample.remote

import android.content.Intent
import com.tuya.smart.tyipc.IPCProvider
import com.tuya.smart.tyipc.KeepAliveService

/**
 *
 * Created by qinchao on 2021/7/22
 */
class RemoteDemoProvider: IPCProvider() {
    override fun onCreate(): Boolean {
        context?.startService(Intent(context, KeepAliveService::class.java))
        return super.onCreate()
    }
}