package com.tuya.smart.sample.remote;

import android.app.Application;

import com.tuya.smart.tyipc.IRemoteService;
import com.tuya.smart.tyipc.Options;
import com.tuya.smart.tyipc.ServiceStore;
import com.tuya.smart.tyipc.TYIpc;

public class RemoteApp extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Options options = new Options();
        TYIpc.init(this, options);
        ServiceStore.registerServiceImpl(RemoteService.class, new RemoteService.RemoteServiceImpl());
    }
}
