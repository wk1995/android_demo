package com.tuya.smart.ipc;

import org.junit.Test;

import java.lang.reflect.Method;
import java.util.Arrays;

/**
 * Created by qinchao on 2021/7/27
 */
public class ReflectTest {

    @Test
    public void test() throws NoSuchMethodException {
        System.out.println("interfaces: " + Arrays.toString(Luqin.class.getInterfaces()));

        Method m = Teacher.class.getMethod("t");
        System.out.println(m.getDeclaringClass());

        m = Luqin.class.getMethod("t");
        System.out.println(m.getDeclaringClass());
    }

    interface People {
        void t();
    }

    interface Teacher extends People {

    }

    interface Worker {

    }

    class Luqin implements Teacher, Worker {

        @Override
        public void t() {

        }
    }
}
