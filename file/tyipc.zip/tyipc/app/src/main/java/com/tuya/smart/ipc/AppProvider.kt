package com.tuya.smart.ipc

import com.tuya.smart.tyipc.IPCProvider

/**
 *
 * Created by qinchao on 2021/7/28
 */
class AppProvider: IPCProvider()