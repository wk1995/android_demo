package com.tuya.smart.sample.remote

import com.tuya.smart.tyipc.IRemoteService

interface RemoteService : IRemoteService {
    fun run()
}