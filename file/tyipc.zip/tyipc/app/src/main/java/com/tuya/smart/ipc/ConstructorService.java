package com.tuya.smart.ipc;

import com.tuya.smart.tyipc.IRemoteService;

public interface ConstructorService extends IRemoteService {
    String getName();
    int getAge();
    String getAddress();
}
