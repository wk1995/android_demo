package com.tuya.smart.ipc.remote

import android.util.Log
import com.tuya.smart.tyipc.KeepAliveService

/**
 *
 * Created by qinchao on 2021/7/30
 */
class RemoteKeepAliveService: KeepAliveService() {

    override fun onCreate() {
        super.onCreate()
        Log.d("tyipc", "RemoteKeepAliveService created")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("tyipc", "RemoteKeepAliveService destroyed")
    }
}