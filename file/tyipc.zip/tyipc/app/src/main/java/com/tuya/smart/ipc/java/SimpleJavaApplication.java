package com.tuya.smart.ipc.java;

import android.app.Application;
import android.content.Context;

import com.tuya.smart.ipc.SimpleCallback2;
import com.tuya.smart.ipc.SimpleMicroService;
import com.tuya.smart.ipc.remote.RemoteKeepAliveService;
import com.tuya.smart.ipc.remote.SimpleMicroServiceImpl;
import com.tuya.smart.tyipc.Options;
import com.tuya.smart.tyipc.ServiceStore;
import com.tuya.smart.tyipc.TYIpc;

import java.util.Arrays;
import java.util.List;

/**
 * Created by qinchao on 2021/7/31
 */
public class SimpleJavaApplication extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        System.out.println("app.hashcode: " + this.hashCode());
        Options options = new Options();
        options.setDebuggable(true);
        options.setInvokeThreshold(Options.INVOKE_THRESHOLD_FORCE_ENABLE);
//        options.setInvokeThreshold(Options.INVOKE_THRESHOLD_DISABLE);
        TYIpc.init(this, options);

        if ("com.tuya.smart.ipc.remote".equals(TYIpc.getProcessName())) {
//            Debug.waitForDebugger();
            ServiceStore.registerServiceImpl(SimpleMicroService.class, new SimpleMicroServiceImpl());
        } else if ("com.tuya.smart.ipc".equals(TYIpc.getProcessName())) {
            ServiceStore.registerServiceImpl(SimpleMicroService.class, new SimpleMicroServiceImpl());
        }

        ServiceStore.registerKeepAliveService(RemoteKeepAliveService.class, ":remote", true);
        ServiceStore.registerServiceProcess(SimpleMicroService.class, ":remote");

        TYIpc.addServiceFinder((clazz, consTypes, constArgs) -> {
            System.out.println("onFind: " + clazz + ", " + Arrays.toString(consTypes) + ", " + Arrays.toString(constArgs));
            return null;
        });
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    public void test(List list, List<String> list2) {

    }
}
