package com.tuya.smart.ipc;

import com.tuya.smart.tyipc.IRemoteService;

public interface MainProcessService extends IRemoteService {
    String mainProcessName();
}
