package com.tuya.smart.ipc;

public interface SimpleCallback3 {
    void onCallback(long l);
}
