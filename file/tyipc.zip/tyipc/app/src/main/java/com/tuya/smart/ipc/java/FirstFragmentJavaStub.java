package com.tuya.smart.ipc.java;

import android.os.IBinder;
import android.os.RemoteException;
import android.os.SystemClock;

import com.tuya.smart.ipc.SimpleMicroService;
import com.tuya.smart.ipc.aidl.Async;
import com.tuya.smart.tyipc.TYIpc;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class FirstFragmentJavaStub {

    public FirstFragmentJavaStub() {

    }

    public static void onClick() {
        TYIpc.getRemoteService(SimpleMicroService.class).invokeWithCallback(() -> {
            System.out.println("invokeWithCallback1 success.");
        });

        TYIpc.getRemoteService(SimpleMicroService.class).invokeWithCallback3(s -> {

            System.out.println("invokeWithCallback3 success: " + s);
        });

        SimpleMicroService service = TYIpc.getRemoteService(SimpleMicroService.class);

        IBinder binder = service.getAsync();
        Async async = Async.Stub.asInterface(binder);

//        Executor executor = Executors.newFixedThreadPool(20);
//        for (int i = 0; i < 10; i++) {
//            int finalI = i;
//            executor.execute(() -> {
//                try {
//                    async.asyncCall(1000 - finalI * 100);
//                } catch (RemoteException e) {
//                    e.printStackTrace();
//                }
//            });
//        }

        for (int i = 0; i < 10; i++) {
            long start = SystemClock.elapsedRealtimeNanos();
            service.setInt(1000 - i * 100);
            long spent = SystemClock.elapsedRealtimeNanos() - start;
            System.out.println("invoke normal call " + (1000 - i * 100) + ", spent " + spent);
        }

        for (int i = 0; i < 10; i++) {
            try {
                long start = SystemClock.elapsedRealtimeNanos();
                async.asyncCall(1000 - i * 100);
                long spent = SystemClock.elapsedRealtimeNanos() - start;
                System.out.println("invoke oneway asyncCall " + (1000 - i * 100) + ", spent " + spent);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        }


    }
}
