package com.tuya.smart.ipc

import android.app.Application
import android.content.Context
import com.tuya.smart.ipc.remote.RemoteKeepAliveService
import com.tuya.smart.ipc.remote.SimpleMicroServiceImpl
import com.tuya.smart.tyipc.ServiceStore
import com.tuya.smart.tyipc.TYIpc

/**
 *
 * Created by qinchao on 2021/7/22
 */
class SimpleApplication: Application() {

    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        println("attachBaseContext onCreate")
//        Thread.sleep(1000)
        TYIpc.init(this, debuggable = true)
        if (TYIpc.processName == "com.tuya.smart.ipc") {

        } else if (TYIpc.processName == "com.tuya.smart.ipc.remote") {
            ServiceStore.registerServiceImpl(SimpleMicroService::class.java, SimpleMicroServiceImpl())
        }
        ServiceStore.registerKeepAliveService(RemoteKeepAliveService::class.java, ":remote")
        ServiceStore.registerServiceProcess(SimpleMicroService::class.java, ":remote")
    }

    override fun onCreate() {
        super.onCreate()
        println("application onCreate")
    }
}