package com.tuya.smart.ipc;

import com.tuya.smart.tyipc.IPCProvider;

import org.jetbrains.annotations.NotNull;

public class MainProcessServiceImpl implements MainProcessService{
    @Override
    public String mainProcessName() {
        return "main process name is " + IPCProvider.Companion.getApplicationId();
    }

    @Override
    public void onBinderDeath(@NotNull String process) {

    }
}
