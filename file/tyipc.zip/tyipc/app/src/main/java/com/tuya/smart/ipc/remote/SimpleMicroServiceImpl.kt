package com.tuya.smart.ipc.remote

import android.content.Context
import android.os.IBinder
import android.os.RemoteException
import com.tuya.smart.ipc.SimpleCallback2
import com.tuya.smart.ipc.SimpleCallback3
import com.tuya.smart.ipc.SimpleMicroService
import com.tuya.smart.ipc.aidl.Async

/**
 *
 * Created by qinchao on 2021/7/22
 */
class SimpleMicroServiceImpl: SimpleMicroService {
    override fun invokeWithCallback3(callback: SimpleCallback3) {
        callback.onCallback(10086)
    }

    private var callback: SimpleMicroService.SimpleCallback? = null
    override fun withContext(context: Context?) {
        println("withContext: $context" )
    }

    override fun getInt(): Int {
        return 10
    }

    override fun getString(): String {
        return "simple micro service"
    }

    override fun getLongArray(): LongArray {
        return longArrayOf(10, 20, 30)
    }

    override fun getStringArray(): Array<String> {
        return arrayOf("simple", "micro", "service", "long", "array")
    }

    override fun getParcelable(): SimpleMicroService.ParcelableData {
        val data = SimpleMicroService.ParcelableData()
        data.stringValue = "parcelable data"
        data.intValue = 100
        return data
    }

    override fun getIntList(): List<Int> {
        return listOf(10, 30, 50)
    }

    override fun getStringList(): List<String> {
        return listOf("simple", "micro", "service", "string", "list")
    }

    override fun getWithMultiArguments(
        f: Float,
        d: Double,
        s: String,
        l: List<String>,
        data: SimpleMicroService.ParcelableData
    ): Int {
        println("getWithMultiArguments ---> f: $f, d: $d, s: $s, l: ${l.joinToString(",")}, data: $data")
        return 100
    }

    override fun invokeWithCallback(i: Int, callback: SimpleMicroService.SimpleCallback) {
        this.callback = callback
        println("invoke With Callback: this.toString $this")
        println("invoke With Callback: callback.toString $callback")

        println("invoke With Callback: callback.equals1 ${callback.equals(callback)}")


        println("invoke With Callback: $i")
        println("invoke With Callback then callback return: " + callback.onCallback("callback invoked: ${i + 1}"))
    }

    override fun invokeWithCallback(callback: SimpleCallback2) {
        callback.onCallback()
    }

    override fun setInt(intValue: Int) {
        println("setInt $intValue")
    }

    override fun setString(stringValue: String) {
        println("setString $stringValue")
    }

    override fun setLongArray(longValue: LongArray) {
        val start = System.currentTimeMillis()
        println("setLongArray: ${longValue.joinToString(" ")}")
        println("setLongArray spent ${System.currentTimeMillis() - start}")
    }

    override fun setStringArray(stringArray: Array<String>) {
        println("setStringArray: ${stringArray.joinToString(" ")}")
    }

    override fun setParcelable(parcelable: SimpleMicroService.ParcelableData) {
        println("setParcelable: $parcelable")
    }

    override fun setParcelableArray(parcelables: Array<SimpleMicroService.ParcelableData>) {
        println("setParcelableArray: ${parcelables.contentToString()}")
    }

    override fun setIntList(intList: List<Int>) {
        println("setIntList: ${intList.joinToString(" ")}")
    }

    override fun setStringList(stringList: List<String>) {
        println("setStringList: ${stringList.joinToString(" ")}")
    }

    override fun setMultiArguments(
        f: Float,
        d: Double,
        s: String,
        l: List<String>,
        data: SimpleMicroService.ParcelableData
    ) {
        println("setMultiArguments ---> f: $f, d: $d, s: $s, l: ${l.joinToString(" ")}, data: $data")
    }

    override fun slowMethod() {
        Thread.sleep(300)
    }

    override fun weightMethod(weightMethodCount: Int) {
        println("weight method start $weightMethodCount in thread ${Thread.currentThread().name}")
        Thread.sleep(10000)
        println("weight method done $weightMethodCount")
    }

    private val binder: Async = object : Async.Stub() {
        override fun asyncCall(weightMethodCount: Int) {
            println("weight method start $weightMethodCount in thread ${Thread.currentThread().name}")
            Thread.sleep(10000)
            println("weight method done $weightMethodCount")
        }

    }

    override fun getBinder(): IBinder {
        return binder.asBinder()
    }

    override fun emptyMethod(): Int {
        return 0
    }

    override fun getAsync(): IBinder {
        return async.asBinder()
    }

    private val async: Async = object : Async.Stub() {
        @Throws(RemoteException::class)
        override fun asyncCall(weightMethodCount: Int) {
            Thread.sleep(weightMethodCount.toLong())
            println("asyncCall($weightMethodCount)")
        }
    }


    override fun onBinderDeath(process: String) {
        println("SimpleMicroService Impl binder death: $process")
    }

}