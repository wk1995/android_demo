package com.tuya.smart.ipc

import android.content.Context
import android.os.IBinder
import android.os.Parcel
import android.os.Parcelable
import com.tuya.smart.ipc.aidl.Async
import com.tuya.smart.tyipc.IPCallback
import com.tuya.smart.tyipc.IRemoteService

/**
 *
 * Created by qinchao on 2021/7/22
 */
interface SimpleMicroService: IRemoteService {

    fun withContext(context: Context?)

    fun getInt(): Int
    fun getString(): String
    fun getLongArray(): LongArray
    fun getStringArray(): Array<String>
    fun getParcelable(): ParcelableData
    fun getIntList(): List<Int>
    fun getStringList(): List<String>
    fun getWithMultiArguments(f: Float, d: Double, s: String, l: List<String>, data: ParcelableData): Int
    fun invokeWithCallback(i: Int, callback: SimpleCallback)

    fun invokeWithCallback(callback: SimpleCallback2)

    fun invokeWithCallback3(callback: SimpleCallback3)

    fun setInt(intValue: Int)
    fun setString(stringValue: String)
    fun setLongArray(longValue: LongArray)
    fun setStringArray(stringArray: Array<String>)
    fun setParcelable(parcelable: ParcelableData)
    fun setParcelableArray(parcelable: Array<ParcelableData>)
    fun setIntList(intList: List<Int>)
    fun setStringList(stringList: List<String>)
    fun setMultiArguments(f: Float, d: Double, s: String, l: List<String>, data: ParcelableData)

    fun slowMethod()

    fun weightMethod(weightMethodCount: Int)
    fun getBinder(): IBinder

    fun emptyMethod(): Int

    fun getAsync(): IBinder

    class ParcelableData() : Parcelable {
        var stringValue: String? = null
        var intValue: Int = 0

        constructor(parcel: Parcel) : this() {
            intValue = parcel.readInt()
            stringValue = parcel.readString()
        }

        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeInt(intValue)
            parcel.writeString(stringValue)
        }

        override fun describeContents(): Int {
            return 0
        }

        override fun toString(): String {
            return "ParcelableData(stringValue=$stringValue, intValue=$intValue)"
        }

        companion object CREATOR : Parcelable.Creator<ParcelableData> {
            override fun createFromParcel(parcel: Parcel): ParcelableData {
                return ParcelableData(parcel)
            }

            override fun newArray(size: Int): Array<ParcelableData?> {
                return arrayOfNulls(size)
            }
        }
    }

    interface SimpleCallback: IPCallback {
        fun onCallback(s: String): Int
    }
}