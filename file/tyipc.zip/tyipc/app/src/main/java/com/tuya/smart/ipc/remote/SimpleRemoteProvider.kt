package com.tuya.smart.ipc.remote

import com.tuya.smart.tyipc.IPCProvider

/**
 *
 * Created by qinchao on 2021/7/22
 */
class SimpleRemoteProvider: IPCProvider() {

}