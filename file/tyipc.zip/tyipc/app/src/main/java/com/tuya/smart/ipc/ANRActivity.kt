package com.tuya.smart.ipc

import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AppCompatActivity
import com.tuya.smart.ipc.databinding.AnrActivityBinding

class ANRActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = AnrActivityBinding.inflate(LayoutInflater.from(this))
        AnrActivityBinding.bind(binding.root)

        binding.back.setOnClickListener {
            onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        Thread.sleep(10000)
    }


    override fun onStop() {
        super.onStop()
        Thread.sleep(10000)
    }

}