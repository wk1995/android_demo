package com.tuya.smart.ipc;

public interface SimpleCallback2 {
    void onCallback();
}
