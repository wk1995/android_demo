package com.tuya.smart.ipc.remote;

import com.tuya.smart.ipc.ConstructorService;

public class ConstructorServiceImpl implements ConstructorService {

    private String name;

    private String address;

    private int age;

    public ConstructorServiceImpl(String name, int age, String address) {
        this.name = name;
        this.address = address;
        this.age = age;
    }

    @Override
    public String toString() {
        return "ConstructorServiceImpl{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", age=" + age +
                '}';
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getAge() {
        return age;
    }

    @Override
    public String getAddress() {
        return address;
    }
}
