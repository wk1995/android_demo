package com.tuya.smart.ipc

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.LifecycleOwner
import com.tuya.smart.ipc.databinding.FragmentFirstBinding
import com.tuya.smart.ipc.java.FirstFragmentJavaStub
import com.tuya.smart.ipc.java.SimpleJavaApplication
import com.tuya.smart.sample.remote.RemoteService
import com.tuya.smart.tyipc.GcTrigger.Default.runGc
import com.tuya.smart.tyipc.TYIpc

/**
 * A simple [Fragment] subclass as the default destination in the navigation.
 */
class FirstFragment : Fragment() {

    private var _binding: FragmentFirstBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        _binding = FragmentFirstBinding.inflate(inflater, container, false)
        return binding.root

    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.buttonGc.setOnClickListener {
            runGc()
        }

        binding.binderThreadPool.setOnClickListener {
        }

        binding.buttonWeakQueue.setOnClickListener {
        }

        binding.buttonNew.setOnClickListener {
//            val intent = Intent(context, MainActivity::class.java)
//            startActivity(intent)
//            requestPermissions(arrayOf("permission.com.tuya.smart.sample.remote"), 0)

//            TYIpc.getRemoteService(RemoteService::class.java, "com.tuya.smart.sample.remote").run()

            SimpleJavaApplication::class.java.methods.filter {
                it.name == "test"
            }.forEach {
                it.genericParameterTypes.forEach {
                    println("${it.javaClass} -- $it")
                }
            }
        }

        binding.buttonFirst.setOnClickListener {
//            findNavController().navigate(R.id.action_FirstFragment_to_SecondFragment)
//            context?.contentResolver?.apply {
//                query(Uri.parse("content://com.tuya.smart.tyrpc"), null, null, null, null)
//            }

//            val intent = Intent(context, ANRActivity::class.java)
//            context?.startActivity(intent)

            FirstFragmentJavaStub.onClick()

            try {
                val simpleService = TYIpc.getRemoteService(SimpleMicroService::class.java)
                println("getInt: ${simpleService.getInt()}")
                println("getIntList: ${simpleService.getIntList().joinToString(separator = " ")}")
                println(
                    "getLongArray: ${
                        simpleService.getLongArray().joinToString(separator = " ")
                    }"
                )
                println("getParcelable: ${simpleService.getParcelable()}")
                println("getString: ${simpleService.getString()}")
                println(
                    "getStringArray: ${
                        simpleService.getStringArray().joinToString(separator = " ")
                    }"
                )
                println("getStringList: ${simpleService.getStringList().joinToString(" ")}")
                val parcelData = SimpleMicroService.ParcelableData()
                parcelData.intValue = 7
                parcelData.stringValue = "8s"
                println(
                    "getWith: ${
                        simpleService.getWithMultiArguments(
                            1.0f,
                            2.0,
                            "3s",
                            listOf("5", "6"),
                            parcelData
                        )
                    }"
                )

                simpleService.invokeWithCallback(100, object : SimpleMicroService.SimpleCallback {
                    override fun onCallback(s: String): Int {
                        println("invokeWitchCallback onCallback: $s")
                        return 10086
                    }

                    override fun getLifecycleOwner(): LifecycleOwner {
                        return viewLifecycleOwner
                    }

                    override fun onBinderDeath(process: String) {
                        println("on binder death!!!")
                    }
                })

                println("toString: $simpleService")
                val simpleMicroService1 = simpleService
                val simpleMicroService2 = TYIpc.getRemoteService(SimpleMicroService::class.java)

                println("equals1: ${simpleService == simpleMicroService1}")
                println("equals2: ${simpleService == simpleMicroService2}")

                simpleService.invokeWithCallback {
                    println("simpleCallback2 callback")
                }

                simpleService.apply {
                    setInt(100)
                    setIntList(listOf(100, 200, 300))
                    setLongArray(longArrayOf(50, 100, 150L))
                    val data = SimpleMicroService.ParcelableData()

                    val dataArray = Array(5) { SimpleMicroService.ParcelableData() }

                    data.stringValue = "set parcelable data"
                    data.intValue = 10086
                    setParcelable(data)
                    setParcelableArray(dataArray)
                    setStringArray(arrayOf("setStringArray", "hello", "world"))
                    setString("setString")
                    setStringList(listOf("setStringList", "hello", "world"))

                    withContext(context)

                }
            } catch (e: Throwable) {
                e.printStackTrace()
            }

//            val constructorService = TYIpc.getRemoteService(
//                ConstructorService::class.java
//                , null
//                , arrayOf(String::class.java, Int::class.java, String::class.java)
//                , arrayOf("luqin", 18, "hua ce")
//            )
//            println("constructor service: ${constructorService.name}, ${constructorService.age}, ${constructorService.address}")

        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        println("onRequestPermissionsResult: $requestCode, ${permissions.joinToString(",")}, ${grantResults.joinToString(",")}")
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
    }
}