package com.tuya.smart.ipc

import android.annotation.SuppressLint
import android.os.Bundle
import android.os.IBinder
import android.util.Log
import com.google.android.material.snackbar.Snackbar
import androidx.appcompat.app.AppCompatActivity
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import androidx.navigation.ui.setupActionBarWithNavController
import android.view.Menu
import android.view.MenuItem
import com.tuya.smart.ipc.databinding.ActivityMainBinding
import com.tuya.smart.tyipc.TYIpc
import com.tuya.smart.tyipc.aidl.IPCMethodResult
import com.tuya.smart.tyipc.aidl.IPCRemoteMethod
import com.tuya.smart.tyipc.aidl.IPCService
import com.tuya.smart.tyipc.aidl.IPCallbackMethod

class MainActivity : AppCompatActivity() {

    private lateinit var appBarConfiguration: AppBarConfiguration
    private lateinit var binding: ActivityMainBinding

    private val testService = object: IPCService.Stub() {
        override fun invokeMethod(ipcMethod: IPCRemoteMethod?): IPCMethodResult {
            Log.d("tyipc", "testService  invokeMethod!!")
            return IPCMethodResult()
        }

        override fun invokeCallbackMethod(ipcMethod: IPCallbackMethod?): IPCMethodResult {
            Log.d("tyipc", "testService  invokeCallbackMethod!!")
            return IPCMethodResult()
        }

        override fun unRegisterCallbackMethod(fromProcess: String?, methodId: String?) {
            Log.d("tyipc", "testService  unRegisterCallbackMethod!!")
        }

    }

    @SuppressLint("PrivateApi")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        val navController = findNavController(R.id.nav_host_fragment_content_main)
        appBarConfiguration = AppBarConfiguration(navController.graph)
        setupActionBarWithNavController(navController, appBarConfiguration)

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAction("Action", null).show()
        }
        println("1. remote exist:  ${TYIpc.isRemoteServiceExist(SimpleMicroService::class.java)}")
        println("2. remote exist:  ${TYIpc.getRemoteService(SimpleMicroService::class.java).remoteServiceExist()}")

//        val clazz = Class.forName("android.os.ServiceManager")
//        val method = clazz.getMethod("addService", String::class.java, IBinder::class.java)
//        method.invoke(null, "test.ipc.service", testService)
    }

    override fun onResume() {
        super.onResume()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        return when (item.itemId) {
            R.id.action_settings -> true
            else -> super.onOptionsItemSelected(item)
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment_content_main)
        return navController.navigateUp(appBarConfiguration)
                || super.onSupportNavigateUp()
    }
}