package com.tuya.smart.tyipc

import android.annotation.SuppressLint
import android.content.Context
import com.tuya.smart.tyipc.aidl.IPCRemoteMethod
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy
import java.util.*


@SuppressLint("StaticFieldLeak")
object TYIpc {

    internal lateinit var context: Context

    internal val authority: String
        get() = IPCProvider.processName

    internal var aliveStrategy: AliveStrategy = AliveStrategy.IGNORE

    @JvmStatic val processName:String
        get() = IPCProvider.processName

    internal var classLoader = ParcelablePrimitiveClassLoader(javaClass.classLoader!!)

    internal var debuggable: Boolean = false

    internal lateinit var options: Options

    @JvmStatic
    internal var serviceFinders: ArrayList<IServiceFinder> = arrayListOf()

    @JvmStatic
    @JvmOverloads
    @Deprecated("fun init with options instead")
    fun init(context: Context, debuggable: Boolean = false, aliveStrategyHandler: AliveStrategy.AliveStrategyHandler? = null) {
        this.context = context
        this.debuggable = debuggable
        this.options = Options()
        aliveStrategyHandler?.apply {
            aliveStrategy = AliveStrategy.CUSTOM
            aliveStrategy.setCustomAliveStrategyHandler(this)
        }
    }

    @JvmStatic
    fun init(context: Context, options: Options = Options()) {
        init(context, debuggable = options.debuggable, aliveStrategyHandler = options.aliveStrategyHandler)
        this.options = options
    }

    @JvmStatic
    @JvmOverloads
    fun <T: IRemoteService> getRemoteService(remoteClass: Class<T>, process: String? = null, constructorTypes: Array<Class<*>>? = null, constructorArgs: Array<*>? = null): T {
        if (constructorArgs != null && constructorTypes != null && constructorArgs.size != constructorTypes.size) {
            throw IllegalArgumentException("constructor arguments' size not match: args{${constructorArgs}}, types{${constructorTypes}}")
        }
        if ((constructorArgs == null && constructorTypes != null) || (constructorArgs != null && constructorTypes == null)) {
            throw IllegalArgumentException("constructor arguments not match: arguments and it's types should be null or not null at the same time")
        }

        return Proxy.newProxyInstance(classLoader, Array(1) { remoteClass } , object: InvocationHandler{
            private val objectDelegate = Any()
            private val delegateId = objectDelegate.hashCode() xor (System.currentTimeMillis().toInt())

            override fun invoke(proxy: Any?, method: Method, args: Array<Any?>?): Any? {
                if (method.declaringClass == IRemoteService::class.java) {
                    if (method.name == "isBinderDeath" && method.parameterTypes.isEmpty()) {
                        return false // 可以实时拉起并同步执行，所以即使进程死亡也不影响方法调用
                    } else if (method.name == "remoteServiceExist" && method.parameterTypes.isEmpty()) {
                        return ServiceStore.remoteServiceExist(remoteClass)
                    } else if (method.name == "remoteProcessName") {
                        return process ?: ServiceStore.getServiceProcess(remoteClass)
                    }
                }
                ServiceProvider.doFind(
                    IPCProvider.processName,
                    delegateId,
                    remoteClass,
                    consTypes = constructorTypes,
                    constArgs = constructorArgs
                )?.let {

                    return if (args.isNullOrEmpty()) {
                        method.invoke(it)
                    } else {
                        method.invoke(it, *args)
                    }
                }

                // 拦截父类Object方法
                if (method.declaringClass == Any::class.java) {
                    if (method.name == "toString" && (args == null || args.isEmpty())) {
                        return "remote service delegate: $objectDelegate"
                    } else if (method.name == "equals" && args?.size == 1) {
                        return args[0].hashCode() == objectDelegate.hashCode()
                    } else if (method.name == "hashCode" && (args == null || args.isEmpty())) {
                        return objectDelegate.hashCode()
                    }
                    // wait, notify, join等方法使用delegate
                    return method.invoke(objectDelegate, args)
                }
                val remoteMethod = IPCRemoteMethod()
                remoteMethod.clazz = remoteClass
                remoteMethod.method = method.name
                remoteMethod.returnType = method.returnType
                remoteMethod.args = args
                remoteMethod.argTypes = method.parameterTypes
                remoteMethod.consTypes = constructorTypes
                remoteMethod.consArgs = constructorArgs
                remoteMethod.delegateId = delegateId
                return IPCInvoker.methodInvoke(process, remoteMethod)
            }

        }) as T
    }

    @JvmStatic
    fun isRemoteServiceExist(serviceClass: Class<out IRemoteService>):Boolean {
        return ServiceStore.remoteServiceExist(serviceClass)
    }

    @JvmStatic
    fun addServiceFinder(serviceFinder: IServiceFinder) {
        serviceFinders.add(serviceFinder)
    }
}

internal fun showSlowInvoke(consumer: Long): Boolean {
    return when {
        TYIpc.options.invokeThreshold == Options.INVOKE_THRESHOLD_FORCE_ENABLE -> {
            true
        }
        TYIpc.options.invokeThreshold == Options.INVOKE_THRESHOLD_DISABLE -> {
            false
        }
        consumer > TYIpc.options.invokeThreshold -> {
            true
        }
        else -> false
    }
}

internal var logger: ILogger = ILogger.SimpleLogger
