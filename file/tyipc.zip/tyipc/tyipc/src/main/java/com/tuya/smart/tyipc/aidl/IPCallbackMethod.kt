package com.tuya.smart.tyipc.aidl

import android.os.Parcel
import android.os.Parcelable
import com.tuya.smart.tyipc.*

/**
 *
 * Created by qinchao on 2021/7/28
 */
@Suppress("UNCHECKED_CAST")
class IPCallbackMethod() : IPCMethod(), Parcelable {

    internal var callbackMethodId: String? = null

    constructor(parcel: Parcel): this() {
        callbackMethodId = parcel.readString()
        fromProcess = parcel.readString()
        clazz = parcel.readSerializable() as Class<IRemoteService>
        method = parcel.readString()!!
        returnType = parcel.readSerializable() as Class<*>?

        val isArgTypesNull = parcel.readInt() == 0
        val argTypesSize = parcel.readInt()
        val primitives = parcel.readInt()
        val tmpTypes = Array<Class<*>?>(argTypesSize) {null}
        if (!isArgTypesNull && argTypesSize > 0) {
            val primitiveMask = 1
            for (i in 0 until argTypesSize) {
                if (primitives and (primitiveMask shl i) != 0) {
                    tmpTypes[i] = readPrimitiveType(parcel.readInt())
                } else {
                    tmpTypes[i] = parcel.readSerializable() as Class<*>?
                }
            }
        }
        argTypes = tmpTypes as Array<out Class<*>>
        args = parcel.readValue(TYIpc.classLoader) as Array<Any?>?
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(callbackMethodId)
        parcel.writeString(myProcess)
        parcel.writeSerializable(clazz)
        parcel.writeString(method)
        parcel.writeSerializable(returnType)
        parcel.writeInt(if (argTypes == null) 0 else 1 )        // isArgTypesNull
        parcel.writeInt(if (argTypes == null) 0 else argTypes!!.size) // argTypesSize
        var primitives = 0
        var indexMask = 1
        argTypes?.onEach {  clazz ->
            // find primitive type arguments
            if (isPrimitiveType(clazz)) {
                primitives = primitives or indexMask
            }
            indexMask = indexMask shl 1
        }
        parcel.writeInt(primitives)
        var index = 0
        argTypes?.onEach { clazz ->
            when {
                isPrimitiveType(clazz) -> writePrimitiveType(clazz, parcel)
                isCallbackType(clazz) -> {
                    throw UnsupportedOperationException("ipc callback in callback method is not support")
                }
                else -> parcel.writeSerializable(clazz)
            }
            index += 1
        }
        parcel.writeValue(args)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<IPCallbackMethod> {
        override fun createFromParcel(parcel: Parcel): IPCallbackMethod {
            return IPCallbackMethod(parcel)
        }

        override fun newArray(size: Int): Array<IPCallbackMethod?> {
            return arrayOfNulls(size)
        }
    }
}