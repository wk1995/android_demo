package com.tuya.smart.tyipc

import android.content.ComponentName
import android.content.Intent
import android.content.ServiceConnection
import android.os.IBinder
import android.os.Process

enum class AliveStrategy {
    KEEP_ALIVE, IGNORE, CUSTOM;

    private var strategyHandler: AliveStrategyHandler? = null

    fun setCustomAliveStrategyHandler(handler: AliveStrategyHandler?) {
        this.strategyHandler = handler
    }

    fun onBinderDeath(process: String) {
        when(this) {
            KEEP_ALIVE -> doKeepAlive(process)
            IGNORE -> doIgnore()
            CUSTOM -> strategyHandler?.onBinderDeath(process)
        }
    }

    private fun doKeepAlive(process: String) {
        val serviceClazz = ServiceStore.getKeepAliveServiceClass(process)
        if (serviceClazz == null) {
            logger.d(message = "keep alive service process(${process}) not found!!!, current process is ${IPCProvider.processName}(${Process.myPid()})")
            return
        }
        val intent = Intent(TYIpc.context, serviceClazz)
        TYIpc.context.startService(intent)
        TYIpc.context.bindService(intent, object: ServiceConnection {
            override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
                service?.linkToDeath( {
                    TYIpc.context.startService(intent)
                    TYIpc.context.bindService(intent, this, 0)
                },0)
            }

            override fun onServiceDisconnected(name: ComponentName?) {
                logger.d(message = "onServiceDisconnected: $name")
                try {
                    TYIpc.context.unbindService(this)
                } catch (e: Throwable) {
                    e.printStackTrace()
                }
            }
        }, 0)
    }

    private fun doIgnore() {
        // do nothing
    }

    interface AliveStrategyHandler {
        fun onBinderDeath(process: String)
    }
}