package com.tuya.smart.tyipc

/**
 *
 * Created by qinchao on 2021/7/23
 * 兼容处理JAVA原生类对象
 */
class ParcelablePrimitiveClassLoader(parent: ClassLoader): ClassLoader(parent) {

    override fun findClass(name: String?): Class<*> {
        val convertName:String? = when(name) {
            "int" -> "I"
            "char" -> "C"
            "byte" -> "B"
            "short" -> "S"
            "long" -> "J"
            "float" -> "F"
            "double" -> "D"
            "boolean" -> "Z"
            "void" -> "V"
            else -> name
        }
        return super.findClass(convertName)
    }

//    override fun loadClass(name: String?): Class<*> {
//        return when(name) {
//            "int" -> Int::class.javaPrimitiveType!!
//            "char" -> Char::class.javaPrimitiveType!!
//            "byte" -> Byte::class.javaPrimitiveType!!
//            "short" -> Short::class.javaPrimitiveType!!
//            "long" -> Long::class.javaPrimitiveType!!
//            "float" -> Float::class.javaPrimitiveType!!
//            "double" -> Double::class.javaPrimitiveType!!
//            "boolean" -> Boolean::class.javaPrimitiveType!!
//            else -> super.loadClass(name)
//        }
//    }
}