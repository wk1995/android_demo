package com.tuya.smart.tyipc

import androidx.lifecycle.LifecycleOwner


/**
 *
 * Created by qinchao on 2021/7/28
 */
interface IPCallback : IRemoteService {
    fun getLifecycleOwner(): LifecycleOwner?
}