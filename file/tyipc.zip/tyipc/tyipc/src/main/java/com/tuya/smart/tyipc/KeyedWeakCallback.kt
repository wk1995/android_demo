package com.tuya.smart.tyipc

import java.lang.ref.ReferenceQueue
import java.lang.ref.WeakReference

/**
 *
 * Created by qinchao on 2021/7/28
 */
class KeyedWeakCallback(
    val key: String,
    reference: Any,
    val process: String,
    queue: ReferenceQueue<Any>,
) : WeakReference<Any>(reference, queue) {

}