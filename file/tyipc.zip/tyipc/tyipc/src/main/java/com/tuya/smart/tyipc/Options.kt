package com.tuya.smart.tyipc

class Options {

    companion object {
        const val INVOKE_THRESHOLD_DISABLE = -1L
        const val INVOKE_THRESHOLD_FORCE_ENABLE = -2L
    }

    var invokeThreshold = INVOKE_THRESHOLD_DISABLE

    var debuggable: Boolean = false

    var aliveStrategyHandler: AliveStrategy.AliveStrategyHandler? = null
}