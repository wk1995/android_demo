package com.tuya.smart.tyipc

import android.app.Service
import android.util.ArrayMap
import org.jetbrains.annotations.TestOnly
import java.util.concurrent.ConcurrentHashMap

/**
 * 外部使用方注册服务实现
 */
object ServiceStore {

    private val processMap = ConcurrentHashMap<Class<*>, String>()

    private val serviceImpls = ConcurrentHashMap<Class<*>, IRemoteService>()

    private val keepAliveServices = ConcurrentHashMap<String, Class<out Service>>()

    private val ipcCallbacks = ConcurrentHashMap<String, ArrayMap<String, Any>>()
//    private val ipcCallbacks = HashMap<String, ArrayMap<String, IPCallback>>()


    /**
     * register service for telling other process where to find the service implementation
     *
     * @param serviceClass  the service class, this service is com.tuya.smart.tyipc.IRemoteService
     * @param process   the process of service implementation
     *
     * process name format:
     *  1. full process name like  "com.tuya.smart.tyipc.remote"
     *  or
     *  2. short process name like ":remote"
     *  or
     *  3. otherwise applicationId
     */
    @TestOnly
    @JvmStatic fun registerServiceProcess(serviceClass: Class<out IRemoteService>, process: String) {
        var processFullName = process
        if (process.startsWith(":")) {
            processFullName = IPCProvider.applicationId + process.replace(":", ".")
        } else if (process.isEmpty()) {
            processFullName = IPCProvider.applicationId
        }
        processMap[serviceClass] = processFullName
    }

    /**
     * register service in the process who implements the service interface
     *
     * @param serviceClass the service class, this service is com.tuya.smart.tyipc.IRemoteService
     * @param impl the service implementation,
     */
    @TestOnly
    @JvmStatic fun registerServiceImpl(serviceClass: Class<out IRemoteService>, impl: IRemoteService) {
        serviceImpls[serviceClass] = impl
    }

    /**
     * call this method to keep process alive
     *
     * @param serviceClass the service class, this service is android.app.Service
     * @param process the process name who need keep alive
     * @param startNow start the service right now
     *
     * you need register service in AndroidManifest.xml first
     */
    @JvmOverloads
    @JvmStatic fun registerKeepAliveService(serviceClass: Class<out Service>, process: String, startNow: Boolean = false) {
        var processFullName = process
        if (process.startsWith(":")) {
            processFullName = IPCProvider.applicationId + process.replace(":", ".")
        } else if (process.isEmpty()) {
            processFullName = IPCProvider.applicationId
        }
        keepAliveServices[processFullName] = serviceClass
        TYIpc.aliveStrategy = AliveStrategy.KEEP_ALIVE
        if (startNow) {
            AliveStrategy.KEEP_ALIVE.onBinderDeath(processFullName)
        }
    }

    fun getKeepAliveServiceClass(process: String):Class<out Service>? {
        return keepAliveServices[process]
    }

    fun load() {
        // will be changed by asm in transform
    }

    fun getServiceProcess(serviceClass: Class<*>): String {
        return processMap[serviceClass] ?: throw IllegalStateException("Remote Service not found in any process: $serviceClass")
    }

    fun getServiceImpl(clazz: Class<*>): IRemoteService? {
        return serviceImpls[clazz]
    }

    fun registerMethodCallback(remoteProcess: String, methodId: String, callback: Any) {
        ipcCallbacks[remoteProcess]?.apply {
            put(methodId, callback)
        } ?: run {
            val map = ArrayMap<String, Any>()
            map[methodId] = callback
            ipcCallbacks[remoteProcess] = map
        }
    }

    fun unregisterMethodCallback(remoteProcess: String, methodId: String) {
        ipcCallbacks[remoteProcess]?.apply {
            remove(methodId)
            logger.d(message = "unregisterMethodCallback in $remoteProcess: $methodId")
        }
    }

    fun getMethodCallback(remoteProcess: String, methodId: String):Any? {
        return ipcCallbacks[remoteProcess]?.run {
            return get(methodId)
        }
    }

    private fun clearMethodCallbacks(remoteProcess: String) {
        ipcCallbacks.remove(remoteProcess)
    }

    fun onBinderDeath(process: String) {
        // 通知service死亡
        for ((_, service) in serviceImpls) {
            service.onBinderDeath(process)
        }
        // 通知callbacks死亡
        for ((_, callbackMap) in ipcCallbacks) {
            for ((_, callback) in callbackMap) {
                if (callback is IPCallback) {
                    callback.onBinderDeath(process)
                }
            }
        }
        clearMethodCallbacks(process)
    }

    fun remoteServiceExist(serviceClass: Class<*>): Boolean {
        return processMap[serviceClass] != null
    }
}