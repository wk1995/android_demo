package com.tuya.smart.tyipc

import androidx.annotation.Keep

/**
 * Created by qinchao on 2021/7/22
 */
@Keep
interface IRemoteService {
    /**
     *  !!! don't override this method
     *  it's will be intercepted by proxy
     *
     *  @return return true if origin process is dead
     */
    @JvmDefault fun isBinderDeath(): Boolean { return false } // will be intercepted by proxy

    /**
     * override this method for listening the communication process death
     */
    @JvmDefault fun onBinderDeath(process: String) {}

    /**
     *  !!! don't override this method
     *  it's will be intercepted by proxy
     *
     *  @return return true if origin process is exist
     */
    @JvmDefault fun remoteServiceExist(): Boolean { return false }

    /**
     *  !!! don't override this method
     *  it's will be intercepted by proxy
     *
     *  @return return the name of the process who communication with
     */
    @JvmDefault fun remoteProcessName(): String {
        return ""
    }
}