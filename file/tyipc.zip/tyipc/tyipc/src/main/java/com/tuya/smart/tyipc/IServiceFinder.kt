package com.tuya.smart.tyipc

interface IServiceFinder {
    fun doFind(clazz: Class<*>, consTypes: Array<out Class<*>>?, constArgs: Array<*>?): IRemoteService?
}