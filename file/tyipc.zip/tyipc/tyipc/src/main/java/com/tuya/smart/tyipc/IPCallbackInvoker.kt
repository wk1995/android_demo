package com.tuya.smart.tyipc

import android.os.DeadObjectException
import com.tuya.smart.tyipc.aidl.IPCallbackMethod

/**
 *
 * Created by qinchao on 2021/7/30
 */
object IPCallbackInvoker {

    fun callbackInvoke(
        callbackMethod: IPCallbackMethod,
    ):Any? {
        val process = callbackMethod.fromProcess
        val ipcService = RemoteManager.getRemoteService(process!!)

        try {
            ipcService?.invokeCallbackMethod(callbackMethod)?.apply {
                if (succed) {
                    return value
                } else {
                    logger.e(message = errMessage ?: "callback invoke error !!")
                }
            } ?: run {
                logger.e(message = "callback provider not found!!! $process")
            }
        } catch (e: DeadObjectException) {
            RemoteManager.onBinderDeath(process)
        } catch (e: Throwable) {
//            throw e
            e.printStackTrace()
        }
        return null
    }


    fun unregisterCallback(methodId: String, process: String) {
        val ipcService = RemoteManager.getRemoteService(process)
        try {
            ipcService?.unRegisterCallbackMethod(IPCProvider.processName, methodId)
        } catch (e: DeadObjectException) {
            RemoteManager.onBinderDeath(process)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }
}