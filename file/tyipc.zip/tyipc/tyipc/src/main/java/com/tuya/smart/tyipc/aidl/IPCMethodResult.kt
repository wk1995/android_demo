package com.tuya.smart.tyipc.aidl

import android.os.Parcel
import android.os.Parcelable
import com.tuya.smart.tyipc.TYIpc

class IPCMethodResult() : Parcelable {

    var succed: Boolean = false

    var errMessage: String? = null

    var value: Any? = null

    var invokeConsumer: Long = 0

    constructor(parcel: Parcel) : this() {
        succed = parcel.readInt() == 1
        errMessage = parcel.readString()
        value = parcel.readValue(TYIpc.classLoader)
        invokeConsumer = parcel.readLong()
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeInt( if (succed) 1 else 0 )
        parcel.writeString(errMessage)
        parcel.writeValue(value)
        parcel.writeLong(invokeConsumer)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<IPCMethodResult> {
        override fun createFromParcel(parcel: Parcel): IPCMethodResult {
            return IPCMethodResult(parcel)
        }

        override fun newArray(size: Int): Array<IPCMethodResult?> {
            return arrayOfNulls(size)
        }
    }
}