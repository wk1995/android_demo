package com.tuya.smart.tyipc

import android.os.DeadObjectException
import com.tuya.smart.tyipc.aidl.IPCRemoteMethod

internal object IPCInvoker {


    fun methodInvoke(processName: String?, remoteMethod: IPCRemoteMethod): Any? {
        val start = System.currentTimeMillis()
        val process = processName ?: ServiceStore.getServiceProcess(remoteMethod.clazz)
        var callSuccess = false
        var consumer = 0L
        try {
            remoteMethod.remoteProcess = process
            val ipcService = RemoteManager.getRemoteService(process)
            ipcService?.invokeMethod(remoteMethod)?.apply {

                if (succed) {
                    consumer = invokeConsumer
                    callSuccess = true
                    return value
                } else {
                    logger.e(
                        message = errMessage
                            ?: "invoke error !! (${remoteMethod.returnType} ${remoteMethod.method}(${
                                remoteMethod.argTypes?.let {
                                    return@let (it as Array<*>).contentDeepToString()
                                } ?: ""
                            }))")
                }
            } ?: run {
                logger.e(message = "ipc provider not found!!! $process")
            }
        } catch (e: DeadObjectException) {
            RemoteManager.onBinderDeath(process)
        } catch (e: Throwable) {
//            throw e
            e.printStackTrace()
        } finally {
            val delta = System.currentTimeMillis() - start
            if (showSlowInvoke(delta)) {
                logger.d(
                    message = "${remoteMethod.returnType} ${remoteMethod.method}(${
                        remoteMethod.args?.let {
                            return@let (it as Array<*>).contentDeepToString()
                        } ?: ""
                    }) in ${remoteMethod.clazz.simpleName} invoked ${if (callSuccess) "success" else "fail"} & spent ${delta}ms(${consumer}ms)")
            }
        }
        return null
    }

}