package com.tuya.smart.tyipc

import java.lang.ref.ReferenceQueue
import java.util.concurrent.ConcurrentHashMap

/**
 * CallbacksWatchDog
 * Created by qinchao on 2021/7/29
 */
internal object CallbacksWatcher: Runnable {

    private val queue = ReferenceQueue<Any>()

    private val watchedCallbacks = ConcurrentHashMap<String, KeyedWeakCallback>()


    @Volatile private var started = false


    fun addCallback(key: String, callbackReference: Any, process: String):KeyedWeakCallback {
        if (!started) {
            started = true
            Thread(this, "Callbacks-Watcher").start()
        }
        watchedCallbacks[key] = KeyedWeakCallback(key, callbackReference, process, queue)
        return watchedCallbacks[key]!!
    }

    /**
     * watchdog机制跟踪CallBack
     */
    override fun run() {
        while (started) {
            val ref = queue.remove() as KeyedWeakCallback
            IPCallbackInvoker.unregisterCallback(ref.key, ref.process)
            watchedCallbacks.remove(ref.key)
            logger.d(message = "afterRemove.watchedCallbacks.size = ${ref.get()}:${watchedCallbacks.size}")
        }
    }

    fun onBinderDeath(process: String) {
        for ((_, value) in watchedCallbacks) {
            if (value.process == process) {
                watchedCallbacks.remove(process)
            }
        }
    }
}