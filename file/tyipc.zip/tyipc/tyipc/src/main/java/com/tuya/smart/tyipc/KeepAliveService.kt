package com.tuya.smart.tyipc

import android.app.Service
import android.content.Intent
import android.os.IBinder
import com.tuya.smart.tyipc.aidl.KeepAlive

open class KeepAliveService: Service() {

    private val keepAlive = object: KeepAlive.Stub() { }

    override fun onBind(intent: Intent?): IBinder {
        return keepAlive
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }
}