package com.tuya.smart.tyipc

import android.util.SparseArray

/**
 * 面向内部注册服务实现
 */
internal object ServiceProvider {

    private val serviceImplCache = hashMapOf<String, SparseArray<IRemoteService>>()


    fun doFind(
        fromProcess: String,
        delegateId: Int,
        clazz: Class<*>,
        consTypes: Array<out Class<*>>?,
        constArgs: Array<out Any?>?
    ): IRemoteService? {
        var remoteService = serviceImplCache[fromProcess]?.get(delegateId)
        if (remoteService != null) {
            return remoteService
        }

        synchronized(serviceImplCache) {
            // double check
            remoteService = serviceImplCache[fromProcess]?.get(delegateId)
            if (remoteService == null) {
                remoteService = ServiceStore.getServiceImpl(clazz)
            }
            if (remoteService == null) {
                TYIpc.serviceFinders.forEach {
//                    println("find $clazz impl by delegateId $delegateId")
                    remoteService = it.doFind(clazz, consTypes, constArgs)
                    if (remoteService != null) {
                        if (serviceImplCache[fromProcess] == null) {
                            serviceImplCache[fromProcess] = SparseArray<IRemoteService>()
                        }
                        serviceImplCache[fromProcess]!!.put(delegateId, remoteService)
                        return@forEach
                    }
                }
            }
            return remoteService
        }
    }

    fun onBinderDeath(process: String) {
        synchronized(serviceImplCache) {
            serviceImplCache.remove(process)
        }
    }
}