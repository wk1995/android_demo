package com.tuya.smart.tyipc.aidl

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import android.util.SparseArray
import androidx.core.util.forEach
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.OnLifecycleEvent
import com.tuya.smart.tyipc.*
import java.lang.reflect.InvocationHandler
import java.lang.reflect.Method
import java.lang.reflect.Proxy

@Suppress("UNCHECKED_CAST")
class IPCRemoteMethod() : IPCMethod(), Parcelable {

    lateinit var remoteProcess: String

    /**
     * 构建顺序与写入必须保持一致
     */
    constructor(parcel: Parcel) : this() {
        fromProcess = parcel.readString()
        clazz = parcel.readSerializable() as Class<IRemoteService>
        consArgs = parcel.readSerializable() as Array<Any?>?
        consTypes = parcel.readSerializable() as Array<Class<Any>>?
        delegateId = parcel.readInt()
        method = parcel.readString()!!
        returnType = parcel.readSerializable() as Class<*>?

        val isArgTypesNull = parcel.readInt() == 0
        val argTypesSize = parcel.readInt()
        val primitives = parcel.readInt()
        val specials = parcel.readInt()
        val tmpTypes = Array<Class<*>?>(argTypesSize) { null }
        var callbackIndexMap: SparseArray<Any>? = null
        var parcelableArrayIndexMap: SparseArray<Class<*>>? = null
        var contextIndexes: ArrayList<Int>? = null
        var methodId: String? = null
        if (!isArgTypesNull && argTypesSize > 0) {
            val primitiveMask = 1
            for (i in 0 until argTypesSize) {
                when {
                    primitives and (primitiveMask shl i) != 0 -> {
                        tmpTypes[i] = readPrimitiveType(parcel.readInt())
                    }
                    specials and (primitiveMask shl i) != 0 -> {
                        when(parcel.readInt()) {
                            SpecialTypes.callback -> {
                                methodId = parcel.readString()
                                tmpTypes[i] = parcel.readSerializable() as Class<*>?
                                val callbackProxy = Proxy.newProxyInstance(TYIpc.classLoader,
                                    Array(1) { tmpTypes[i] } ,
                                    object: InvocationHandler {
                                        val callbackDelegate = Any()
                                        override fun invoke(
                                            proxy: Any?,
                                            method: Method,
                                            args: Array<Any?>?
                                        ): Any? {
                                            if (method.declaringClass == IRemoteService::class.java) {
                                                if (method.name == "isBinderDeath" && argTypesSize == 0) {
                                                    return !RemoteManager.isRemoteAlive(fromProcess!!)
                                                } else if (method.name == "remoteProcessName") {
                                                    return fromProcess
                                                }
                                            }
                                            // 拦截父类Object方法
                                            if (method.declaringClass == Any::class.java) {
                                                if (method.name == "toString" && (args == null || args.isEmpty())) {
                                                    return "remote callback delegate: $callbackDelegate"
                                                } else if (method.name == "equals" && args?.size == 1) {
                                                    return args[0].hashCode() == callbackDelegate.hashCode()
                                                } else if (method.name == "hashCode" && (args == null || args.isEmpty())) {
                                                    return callbackDelegate.hashCode()
                                                }
                                                // wait, notify, join等方法使用delegate
                                                return method.invoke(callbackDelegate, args)
                                            }
                                            val callbackMethod = IPCallbackMethod()
                                            callbackMethod.clazz = tmpTypes[i]!!
                                            callbackMethod.method = method.name
                                            callbackMethod.returnType = method.returnType
                                            callbackMethod.args = args
                                            callbackMethod.argTypes = method.parameterTypes
                                            callbackMethod.callbackMethodId = methodId
                                            callbackMethod.fromProcess = fromProcess
                                            return IPCallbackInvoker.callbackInvoke(callbackMethod)
                                        }
                                    })
                                if (callbackIndexMap == null) {
                                    callbackIndexMap = SparseArray()
                                }
                                callbackIndexMap.put(i, callbackProxy)
                            }
                            SpecialTypes.parcelableArray -> {
                                if (parcelableArrayIndexMap == null) {
                                    parcelableArrayIndexMap = SparseArray()
                                }
                                val componentType = Class.forName(parcel.readString()!!, false, TYIpc.classLoader)
                                parcelableArrayIndexMap.put(i, componentType)
                                tmpTypes[i] = parcel.readSerializable() as Class<*>
                            }
                            SpecialTypes.context -> {
                                if (contextIndexes == null) {
                                    contextIndexes = ArrayList()
                                }
                                contextIndexes.add(i)
                                tmpTypes[i] = Context::class.java
                            }
                        }

                    }
                    else -> {
                        tmpTypes[i] = parcel.readSerializable() as Class<*>?
                    }
                }
            }
        }
        argTypes = tmpTypes as Array<out Class<*>>
        args = parcel.readValue(TYIpc.classLoader) as Array<Any?>?
        callbackIndexMap?.forEach { key, value ->
            CallbacksWatcher.addCallback(methodId!!, value, fromProcess!!)
            args?.set(key, value)
        }
        parcelableArrayIndexMap?.forEach { index, componentType ->
            val argInKey = args?.get(index) as Array<Parcelable>?
            argInKey?.apply {
                val realArray = java.lang.reflect.Array.newInstance(componentType, size) as Array<Parcelable>
                args?.set(index, realArray)

                for (i in 0 until size) {
                    realArray[i] = get(i)
                }
            }
        }
        contextIndexes?.forEach { index->
            args?.set(index, TYIpc.context)
        }
    }

    /**
     * 只要是interface都认为是Callback
     */
    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(myProcess)
        parcel.writeSerializable(clazz)
        parcel.writeSerializable(consArgs)
        parcel.writeSerializable(consTypes)
        parcel.writeInt(delegateId)
        parcel.writeString(method)
        parcel.writeSerializable(returnType)
        parcel.writeInt(if (argTypes == null) 0 else 1)    // isArgTypesNull
        parcel.writeInt(if (argTypes == null) 0 else argTypes!!.size)   // argTypesSize
        var primitives = 0
        var specials = 0
        var indexMask = 1
        argTypes?.onEach { clazz ->
            when {
                // find primitive type arguments
                isPrimitiveType(clazz) -> {
                    primitives = primitives or indexMask
                }
                // find callback type arguments
                isCallbackType(clazz) -> {
                    specials = specials or indexMask
                }
                isContext(clazz) -> {
                    specials = specials or indexMask
                }
                isSubClassOfParcelableArrayType(clazz) -> {
                    specials = specials or indexMask
                }
            }
            indexMask = indexMask shl 1
        }
        parcel.writeInt(primitives)
        parcel.writeInt(specials)
        argTypes?.forEachIndexed { index, clazz ->
            when {
                isPrimitiveType(clazz) -> writePrimitiveType(clazz, parcel)
                isCallbackType(clazz) -> {
                    parcel.writeInt(SpecialTypes.callback)
                    var methodId: String? = null
                    args?.get(index)?.apply {
                        val ipcCallback = this
                        if (this is IPCallback) {
                            getLifecycleOwner()?.apply {
                                lifecycle.addObserver(object : LifecycleObserver {
                                    @Suppress("unused")
                                    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
                                    fun onDestroy(owner: LifecycleOwner) {
                                        logger.d(message = "$owner.lifecycle.onDestroy: recycling $methodId in $remoteProcess")
                                        owner.lifecycle.removeObserver(this)
                                        ServiceStore.unregisterMethodCallback(
                                            remoteProcess,
                                            methodId!!
                                        )
                                    }
                                })
                            }
                        }
                        methodId = generateMethodId(index,  clazz, this)
                        ServiceStore.registerMethodCallback(
                            remoteProcess,
                            methodId!!,
                            ipcCallback
                        )
                        args?.set(index, null) // remove origin callback object first
                    }
                    parcel.writeString(methodId)
                    parcel.writeSerializable(clazz)
                }
                isSubClassOfParcelableArrayType(clazz) -> { // 只有Parcelable的子类需求特殊兼容
                    parcel.writeInt(SpecialTypes.parcelableArray)
                    parcel.writeString(clazz.componentType.name)
                    parcel.writeSerializable(clazz)
                }
                isContext(clazz) -> {
                    args?.set(index, null)
                    parcel.writeInt(SpecialTypes.context)
                }
                else -> parcel.writeSerializable(clazz)
            }
        }
        parcel.writeValue(args)
    }

    private fun generateMethodId(index: Int, argType: Class<*>, ipCallback: Any): String {
        return "$clazz#$method#$index#$argType@${ipCallback.hashCode()}"
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<IPCRemoteMethod> {
        override fun createFromParcel(parcel: Parcel): IPCRemoteMethod {
            return IPCRemoteMethod(parcel)
        }

        override fun newArray(size: Int): Array<IPCRemoteMethod?> {
            return arrayOfNulls(size)
        }
    }


    private fun callbackInterfaceCount(clazz: Class<*>, list: MutableList<Class<*>>): Int {
        var count = 0

        clazz.interfaces.onEach {
            if (it == IPCallback::class.java) {
                count += 1
                list.add(it)
            }
            count += callbackInterfaceCount(it, list)
        }

        if (clazz.superclass == Any::class.java || clazz.superclass == null) {
            return count
        }
        return callbackInterfaceCount(clazz.superclass!!.javaClass, list)
    }

    private fun boxPrimitiveType(clazz: Class<*>): Class<Any> {
        return when (clazz) {
            Byte::class.javaPrimitiveType -> Byte.javaClass
            Char::class.javaPrimitiveType -> Char.javaClass
            Short::class.javaPrimitiveType -> Short.javaClass
            Int::class.javaPrimitiveType -> Int.javaClass
            Long::class.javaPrimitiveType -> Long.javaClass
            Float::class.javaPrimitiveType -> Float.javaClass
            Double::class.javaPrimitiveType -> Double.javaClass
            Boolean::class.javaPrimitiveType -> Boolean.javaClass
            else -> clazz as Class<Any>
        }
    }
}
