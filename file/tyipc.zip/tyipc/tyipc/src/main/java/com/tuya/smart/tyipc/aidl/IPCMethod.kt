package com.tuya.smart.tyipc.aidl

import android.content.Context
import android.os.Parcel
import android.os.Parcelable
import com.tuya.smart.tyipc.IPCProvider
import com.tuya.smart.tyipc.IPCallback
import com.tuya.smart.tyipc.IRemoteService
import com.tuya.smart.tyipc.SpecialTypes

/**
 *
 * Created by qinchao on 2021/7/28
 */
abstract class IPCMethod {


    internal lateinit var clazz: Class<*>

    internal lateinit var method: String

    internal var returnType: Class<*>? = null

    internal var args: Array<Any?>? = null

    internal var argTypes: Array<out Class<*>>? = null

    internal var consTypes: Array<out Class<*>>? = null

    internal var consArgs: Array<out Any?>? = null

    internal var myProcess: String? = IPCProvider.processName

    internal var fromProcess: String? = null

    internal var delegateId: Int = -1

    fun isPrimitiveType(clazz: Class<*>): Boolean {
        return when (clazz) {
            Byte::class.javaPrimitiveType -> true
            Char::class.javaPrimitiveType -> true
            Short::class.javaPrimitiveType -> true
            Int::class.javaPrimitiveType -> true
            Long::class.javaPrimitiveType -> true
            Float::class.javaPrimitiveType -> true
            Double::class.javaPrimitiveType -> true
            Boolean::class.javaPrimitiveType -> true
            else -> false
        }
    }

    fun isSpecialTypes(clazz: Class<*>): Boolean {
        return isCallbackType(clazz) || isContext(clazz) || isSubClassOfParcelableArrayType(clazz)
    }

    fun isSubClassOfParcelableArrayType(clazz: Class<*>): Boolean {
        return clazz.isArray && Parcelable::class.java.isAssignableFrom(clazz.componentType!!) && Parcelable::class.java != clazz.componentType
    }

    fun isCallbackType(clazz: Class<*>): Boolean {
        return clazz.isInterface && clazz != List::class.java && clazz != Map::class.java
//                && IPCallback::class.java.isAssignableFrom(clazz)
    }

    fun isContext(clazz: Class<*>) :Boolean {
        return Context::class.java == clazz
    }

    fun writePrimitiveType(clazz: Class<*>, parcel: Parcel) {
        return when (clazz) {
            Byte::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.byte)
            Char::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.char)
            Short::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.short)
            Int::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.int)
            Long::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.long)
            Float::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.float)
            Double::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.double)
            Boolean::class.javaPrimitiveType -> parcel.writeInt(SpecialTypes.Primitives.boolean)
            else -> throw IllegalArgumentException("Unknown primitive type: $clazz")
        }
    }

    fun readPrimitiveType(clazz: Int):Class<*> {
        return when (clazz) {
            SpecialTypes.Primitives.byte -> Byte::class.javaPrimitiveType!!
            SpecialTypes.Primitives.char ->  Char::class.javaPrimitiveType!!
            SpecialTypes.Primitives.short ->  Short::class.javaPrimitiveType!!
            SpecialTypes.Primitives.int -> Int::class.javaPrimitiveType!!
            SpecialTypes.Primitives.long ->  Long::class.javaPrimitiveType!!
            SpecialTypes.Primitives.float ->  Float::class.javaPrimitiveType!!
            SpecialTypes.Primitives.double ->  Double::class.javaPrimitiveType!!
            SpecialTypes.Primitives.boolean ->   Boolean::class.javaPrimitiveType!!
            else -> throw IllegalArgumentException("unknown primitive type: $clazz")
        }
    }
}