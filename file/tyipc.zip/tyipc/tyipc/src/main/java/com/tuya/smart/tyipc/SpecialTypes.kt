package com.tuya.smart.tyipc

/**
 *
 * Created by qinchao on 2021/7/23
 */

internal object SpecialTypes {
    const val context = 0

    const val parcelableArray = 1

    const val callback = 2

    internal object Primitives {
        internal const val byte = 10001
        internal const val char = 10002
        internal const val short = 10003
        internal const val int = 10004
        internal const val long = 10005
        internal const val float = 10006
        internal const val double = 10007
        internal const val boolean = 10008
    }
}
