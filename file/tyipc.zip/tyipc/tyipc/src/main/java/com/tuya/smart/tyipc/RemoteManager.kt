package com.tuya.smart.tyipc

import android.net.Uri
import android.os.IBinder
import com.tuya.smart.tyipc.aidl.IPCService
import com.tuya.smart.tyipc.aidl.ParcelableBinder

/**
 *
 * Created by qinchao on 2021/7/30
 */
object RemoteManager {

    private val remoteServiceMap: MutableMap<String, IPCService> = mutableMapOf()

    fun getRemoteService(process: String): IPCService? {
        if (remoteServiceMap[process] != null) {
            return remoteServiceMap[process]
        }
        val uri = Uri.parse("content://$process")
        val cursor = TYIpc.context.contentResolver.query(uri, null, null, null, null)
        var ipcService: IPCService? = null
        cursor?.apply {
            extras.classLoader = IPCInvoker::class.java.classLoader
            val binderWrapper =
                extras.getParcelable<ParcelableBinder>(IPCProvider.EXTRA_KEY_BINDER)
            binderWrapper?.apply {
                val binder = getBinder<IBinder>()
                binder.linkToDeath({
                    onBinderDeath(process)
                }, 0)
                val service: IPCService = IPCService.Stub.asInterface(getBinder())
                remoteServiceMap[process] = service
                ipcService = service

            }
            close()
        }
        return ipcService
    }

    fun onBinderDeath(process: String) {
        logger.w(message = "process has dead: $process")
        remoteServiceMap.remove(process)
        CallbacksWatcher.onBinderDeath(process)
        ServiceStore.onBinderDeath(process)
        ServiceProvider.onBinderDeath(process)
        TYIpc.aliveStrategy.onBinderDeath(process)
    }

    fun isRemoteAlive(process: String): Boolean {
        return remoteServiceMap[process] != null
    }
}