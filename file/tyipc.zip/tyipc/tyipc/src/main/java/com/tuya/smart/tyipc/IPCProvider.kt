package com.tuya.smart.tyipc

import android.app.ActivityManager
import android.app.Application
import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.*
import android.text.TextUtils
import com.tuya.smart.tyipc.TYIpc.context
import com.tuya.smart.tyipc.aidl.*
import java.util.*

open class IPCProvider: ContentProvider() {
    
    companion object {
        internal const val TAG = "IpcProvider"

        internal const val EXTRA_KEY_BINDER = "extra.key.service"

        private val DEFAULT_COLUMNS = arrayOf("ids")

        internal val processName: String
            get() = initProcessName()!!

        val applicationId: String
            get() = context.packageName

        private var mProcessName: String? = null

        private fun initProcessName(): String? {
            if (!TextUtils.isEmpty(mProcessName)) {
                return mProcessName
            }
            if (Build.VERSION.SDK_INT >= 28) {
                mProcessName = Application.getProcessName()
            } else {
                try {
                    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                    val runningApps = am.runningAppProcesses
                    if (runningApps != null) {
                        for (processInfo in runningApps) {
                            if (processInfo.pid == Process.myPid()) {
                                mProcessName = processInfo.processName
                            }
                        }
                    }
                    if (TextUtils.isEmpty(mProcessName)) {
                        mProcessName = context.packageName
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            mProcessName = mProcessName?.replace(":", ".")
            return mProcessName
        }
    }

    private val ipcService = object : IPCService.Stub() {
        override fun invokeMethod(ipcRemoteMethod: IPCRemoteMethod): IPCMethodResult {
            logger.i(message = "invokeMethod : ${ipcRemoteMethod.returnType} ${ipcRemoteMethod.method}(${ipcRemoteMethod.args?.let {
                return@let (it as Array<*>).contentDeepToString()
            } ?: ""})")
            val result = IPCMethodResult()
            result.succed = true
            val clazzImpl = ServiceProvider.doFind(ipcRemoteMethod.fromProcess!!, ipcRemoteMethod.delegateId, ipcRemoteMethod.clazz, ipcRemoteMethod.consTypes, ipcRemoteMethod.consArgs)
            if (clazzImpl == null) {
                result.succed = false
                result.errMessage = "the impl of ${ipcRemoteMethod.clazz} not found."
                return result
            }
            try {
                if (ipcRemoteMethod.argTypes == null || ipcRemoteMethod.argTypes!!.isEmpty()) {
                    val method = clazzImpl.javaClass.getDeclaredMethod(ipcRemoteMethod.method)
                    method.isAccessible = true
                    val start = System.currentTimeMillis()
                    result.value = method.invoke(clazzImpl)
                    result.invokeConsumer = System.currentTimeMillis() - start
                } else {
                    val method = clazzImpl.javaClass.getDeclaredMethod(ipcRemoteMethod.method, *ipcRemoteMethod.argTypes!!)
                    method.isAccessible = true
                    val start = System.currentTimeMillis()
                    result.value = method.invoke(clazzImpl, *ipcRemoteMethod.args!!)
                    result.invokeConsumer = System.currentTimeMillis() - start
                }
            } catch (e: Throwable) {
                result.succed = false
                result.errMessage = e.message
                e.printStackTrace()
            }
            return result
        }

        override fun invokeCallbackMethod(ipcMethod: IPCallbackMethod): IPCMethodResult {
            val result = IPCMethodResult()
            result.succed = true
            val clazzImpl = ServiceStore.getMethodCallback(ipcMethod.fromProcess!!, ipcMethod.callbackMethodId!!)
            if (clazzImpl == null) {
                result.succed = false
                result.errMessage = "callback of ${ipcMethod.method} not found.  methodId = ${ipcMethod.callbackMethodId}"
                return result
            }
            try {
                if (ipcMethod.argTypes == null || ipcMethod.argTypes!!.isEmpty()) {
                    val method = clazzImpl.javaClass.getDeclaredMethod(ipcMethod.method)
                    method.isAccessible = true
                    result.value = method.invoke(clazzImpl)
                } else {
                    val method = clazzImpl.javaClass.getDeclaredMethod(ipcMethod.method, *ipcMethod.argTypes!!)
                    method.isAccessible = true
                    result.value = method.invoke(clazzImpl, *ipcMethod.args!!)
                }
            } catch (e: Throwable) {
                result.succed = false
                result.errMessage = e.message
                e.printStackTrace()
            }
            return result
        }

        override fun unRegisterCallbackMethod(fromProcess: String, methodId: String) {
            ServiceStore.unregisterMethodCallback(fromProcess, methodId)
        }
    }
    
    override fun onCreate(): Boolean {
        println("provider onCreate")
        return false
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor {
        println("provider query")
        return BinderCursor(ipcService)
    }

    override fun getType(uri: Uri): String? {
        return null
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        return null
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
        return 0
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int {
        return 0
    }
    


    class BinderCursor(binder: IBinder): MatrixCursor(DEFAULT_COLUMNS) {
        
        private val binderExtra: Bundle = Bundle()

        private val stub = ParcelableBinder(binder)

        override fun getExtras(): Bundle {
            return binderExtra
        }

        init {
            binderExtra.classLoader = IPCProvider::class.java.classLoader
            binderExtra.putParcelable(EXTRA_KEY_BINDER, stub)
        }
    }
}