package com.tuya.smart.elapse

import android.content.Context

object Elapse {

    @JvmStatic @JvmOverloads fun init(context: Context, options: ElapseOptions = ElapseOptions()) {
        // do nothing
    }

    @JvmStatic fun dump() {
        // do nothing
    }
}